#include "Scene.h"

#include <glm/glm.hpp>
#include <imgui/imgui.h>

#include "Instance.h"

Scene::Scene(SimpleCamera* _cam, vec2 _windowSize, Light& _global, vec3 _ambient)
	: m_camera(_cam), m_windowSize(_windowSize), m_globalLight(_global),
		m_ambientLightColor(_ambient)
{
}

Scene::~Scene()
{
	for (auto it = m_instances.begin();
		it != m_instances.end(); it++)
	{
		delete* it;
	}
}

void Scene::Update(float _dt, float _time)
{
	// Rotate the light to emulate a 'day/night' cycle
	SetGlobalLightDir(glm::normalize(glm::vec3(glm::cos(_time * 2), glm::sin(_time * 2), 0)));

	ImGuiHelper();
}

void Scene::Draw()
{
	for (int i = 0; i < MAX_LIGHTS && i < GetPointLightCount(); i++)
	{
		m_pointLightPositions[i] = m_pointLights[i].direction;
		m_pointLightColors[i] = m_pointLights[i].color;
	}

	for (auto it = m_instances.begin();
		it != m_instances.end(); it++)
	{
		Instance* instance = *it;
		instance->Draw(this);
	}
}

void Scene::ImGuiHelper()
{
	ImGui::Begin("Light Settings");
	ImGui::DragFloat3("Global Light Direction",
		&GetGlobalLight().direction[0], 0.1f, -1, 1);
	ImGui::DragFloat3("Global Light Color",
		&GetGlobalLight().color[0], 0.1f, 0, 1);
	ImGui::End();
}

void Scene::AddInstance(Instance* _instance)
{
	m_instances.push_back(_instance);
}

void Scene::AddPointLight(Light _light)
{
	m_pointLights.push_back(_light);
}

void Scene::AddPointLight(vec3 _dir, vec3 _colour, float _intensity)
{
	m_pointLights.push_back(Light(_dir, _colour, _intensity));
}

void Scene::SetGlobalLightDir(vec3 _dir)
{
	m_globalLight.direction = _dir;
}

SimpleCamera* Scene::GetCamera() const
{
	return m_camera;
}

vec2 Scene::GetWindowSize() const
{
	return m_windowSize;
}

vec3 Scene::GetAmbientColour() const
{
	return m_ambientLightColor;
}

void Scene::SetAmbientColour(vec3 _colour)
{
	m_ambientLightColor = _colour;
}

Light& Scene::GetGlobalLight()
{
	return m_globalLight;
}

vector<Light>& Scene::GetPointLights()
{
	return m_pointLights;
}

int Scene::GetPointLightCount()
{
	return (int)m_pointLights.size();
}

vec3* Scene::GetPointLightPositions()
{
	return &m_pointLightPositions[0];
}

vec3* Scene::GetPointLightColours()
{
	return &m_pointLightColors[0];
}
