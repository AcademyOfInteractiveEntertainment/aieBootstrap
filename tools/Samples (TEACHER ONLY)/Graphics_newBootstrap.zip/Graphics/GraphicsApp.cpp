#include "GraphicsApp.h"

#include "aie/bootstrap/Gizmos.h"
#include "aie/bootstrap/Input.h"

#include <glm/glm.hpp>
#include <glm/ext.hpp>

#include "Scene.h"
#include "Light.h"
#include "Instance.h"

using glm::vec3;
using glm::vec4;
using glm::mat4;
using aie::Gizmos;

GraphicsApp::GraphicsApp() 
{
	m_viewMatrix = glm::lookAt(vec3(10), vec3(0), vec3(0, 1, 0));
	m_projectionMatrix = glm::perspective(glm::pi<float>() * 0.25f, 16.0f / 9.0f, 0.1f, 1000.0f);
}

GraphicsApp::~GraphicsApp() 
{

}

bool GraphicsApp::Startup() {
	
	SetBackgroundColour(0.25f, 0.25f, 0.25f);

	// initialise gizmo primitive counts
	Gizmos::Create(10000, 10000, 10000, 10000);

	m_ambientLight = { 0.5f, 0.5f, 0.5f };

	Light light;
	light.color = { 1,1,1 };
	light.direction = { 1, -1, 1 };

	// create simple camera transforms
	m_viewMatrix = glm::lookAt(vec3(10), vec3(0), vec3(0, 1, 0));
	m_projectionMatrix = glm::perspective(glm::pi<float>() * 0.25f, 16.0f / 9.0f, 0.1f, 1000.0f);

	m_scene = new Scene(&m_camera, vec2(GetWindowWidth(),
		GetWindowHeight()), light, m_ambientLight);

	m_scene->AddPointLight(vec3(5, 3, 0), vec3(1, 0, 0), 50);
	m_scene->AddPointLight(vec3(-5, 3, 0), vec3(0, 0, 1), 50);

	return LaunchShaders();
}

void GraphicsApp::Shutdown() {

	Gizmos::Destroy();
	delete m_scene;
}

void GraphicsApp::Update(float deltaTime) {

	// wipe the gizmos clean for this frame
	Gizmos::Clear();

	// draw a simple grid with gizmos
	vec4 white(1);
	vec4 black(0, 0, 0, 1);
	for (int i = 0; i < 21; ++i) {
		Gizmos::AddLine(vec3(-10 + i, 0, 10),
			vec3(-10 + i, 0, -10),
			i == 10 ? white : black);
		Gizmos::AddLine(vec3(10, 0, -10 + i),
			vec3(-10, 0, -10 + i),
			i == 10 ? white : black);
	}

	// add a transform so that we can see the axis
	Gizmos::AddTransform(mat4(1));

	m_scene->Update(deltaTime, GetTime());

	m_camera.Update(deltaTime);

	// quit if we press escape
	aie::Input* input = aie::Input::GetInstance();

	if (input->IsKeyDown(aie::INPUT_KEY_ESCAPE))
		Quit();

	if (input->IsKeyDown(aie::INPUT_KEY_SPACE))
		m_scene->GetGlobalLight().color = vec3(0, 1000, 0);
}

void GraphicsApp::Draw() {

	//m_renderTarget.Bind();

	// wipe the screen to the background colour
	ClearScreen();

	m_viewMatrix = m_camera.GetViewMatrix();
	m_projectionMatrix = m_camera.GetProjectionMatrix(
		(float)GetWindowWidth(), (float)GetWindowHeight());

	auto pv = m_projectionMatrix * m_viewMatrix;

	m_scene->Draw();

	Gizmos::Draw(m_projectionMatrix * m_viewMatrix);

	/*m_renderTarget.Unbind();

	ClearScreen();

	m_renderTarget.GetTarget(0).Bind(0);*/
}

bool GraphicsApp::LaunchShaders()
{
	if (!m_renderTarget.Initialise(1, GetWindowWidth(), GetWindowHeight()))
	{
		printf("Render Target Error!\n");
		return false;
	}

#pragma region LoadingShaders
	// Textured Mesh Shader
	m_normalLitShader.LoadShader(aie::eShaderStage::VERTEX,
		"./shaders/normalLit.vert");
	m_normalLitShader.LoadShader(aie::eShaderStage::FRAGMENT,
		"./shaders/normalLit.frag");
	if (!m_normalLitShader.Link())
	{
		printf("Normal Lit Phong Shader Error: %s\n", m_normalLitShader.GetLastError());
		return false;
	}

	// Untextured Mesh Shader
	m_phongShader.LoadShader(aie::eShaderStage::VERTEX,
		"./shaders/phong.vert");
	m_phongShader.LoadShader(aie::eShaderStage::FRAGMENT,
		"./shaders/phong.frag");
	if (!m_phongShader.Link())
	{
		printf("Color Shader Error: %s\n", m_phongShader.GetLastError());
		return false;
	}

#pragma endregion

	m_spearMesh.Load("./soulspear/soulspear.obj", true);

	for (int i = 0; i < 10; i++)
		m_scene->AddInstance(new Instance(vec3(i * 2, 0, 0),
			vec3(0, i * 30, 0), vec3(1, 1, 1),
			&m_spearMesh, &m_normalLitShader));

	return true;
}
