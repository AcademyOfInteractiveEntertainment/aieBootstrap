#pragma once

#include "aie/bootstrap/Texture.h"

namespace aie {

	class RenderTarget {
	public:

		RenderTarget();
		RenderTarget(unsigned int targetCount, unsigned int width, unsigned int height);
		virtual ~RenderTarget();

		bool Initialise(unsigned int targetCount, unsigned int width, unsigned int height, bool use_depth = false);

		void Bind();
		void Unbind();

		unsigned int	GetWidth() const { return m_width; }
		unsigned int	GetHeight() const { return m_height; }

		unsigned int	GetFrameBufferHandle() const { return m_fbo; }

		unsigned int	GetTargetCount() const { return m_targetCount; }
		const Texture& GetTarget(unsigned int target) const { return m_targets[target]; }
		void            BindDepthTarget(unsigned int index) const;

	protected:

		unsigned int	m_width;
		unsigned int	m_height;

		unsigned int	m_fbo;
		unsigned int	m_rbo;

		unsigned int	m_targetCount;
		Texture* m_targets;
		unsigned int    m_depthTarget;
	};

} // namespace aie