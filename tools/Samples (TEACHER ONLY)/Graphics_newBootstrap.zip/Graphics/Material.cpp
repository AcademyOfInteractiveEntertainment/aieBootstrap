#include "Material.h"

#include <assimp/material.h>
#include <glew/glew.h>
#include <stdio.h>

#define TO_STRING(var) #var

#include <iostream>
#include <string>
#include <vector>
#include <tuple>

using std::string;
using std::vector;
using std::tuple;

enum eDataType : char
{
	Float,
	Color
};

string ColorString(aiColor3D _color)
{
	return "r: " + std::to_string(_color.r) +
		" g: " + std::to_string(_color.g) +
		" b: " + std::to_string(_color.b);
}

void aie::Material::LoadFromAssimp(aiMaterial* _material, const string& _folder)
{
	tuple<const char*, eDataType, void*> values[] =
	{
		{ TO_STRING(ambient), eDataType::Color, &ambient },
		{ TO_STRING(diffuse), eDataType::Color, &diffuse },
		{ TO_STRING(specular), eDataType::Color, &specular },
		{ TO_STRING(emissive), eDataType::Color, &emissive },
		{ "shininess", eDataType::Float, &specularPower },
		{ TO_STRING(opacity), eDataType::Float, &opacity }
	};

	for (unsigned int i = 0; i < _material->mNumProperties; i++)
	{
		aiMaterialProperty* prop = _material->mProperties[i];

		for (auto value : values)
		{
			const char* id = std::get<0>(value);

			if (Contains(prop->mKey, id) && std::get<1>(value) == eDataType::Color)
			{
				vec3* color = (vec3*)std::get<2>(value);
				AssignColourProperty(_material, prop, color);
			}
			else if (Contains(prop->mKey, id) && std::get<1>(value) == eDataType::Float)
			{
				float* color = (float*)std::get<2>(value);
				AssignFloatProperty(_material, prop, color);
			}
		}
	}

	AssignTextureProperty(aiTextureType_DIFFUSE, _material, _folder, &diffuseTexture);
	AssignTextureProperty(aiTextureType_OPACITY, _material, _folder, &alphaTexture);
	AssignTextureProperty(aiTextureType_AMBIENT, _material, _folder, &ambientTexture);
	AssignTextureProperty(aiTextureType_SPECULAR, _material, _folder, &specularTexture);
	AssignTextureProperty(aiTextureType_SHININESS, _material, _folder, &specularHighlightTexture);
	bool flag = AssignTextureProperty(aiTextureType_NORMALS, _material, _folder, &normalTexture);
	AssignTextureProperty(aiTextureType_DISPLACEMENT, _material, _folder, &displacementTexture);

	// Because of obj's seeing normals as bump, if it isn't already set, we will try
	// the normal texture as a height map
	if (!flag)
		AssignTextureProperty(aiTextureType_HEIGHT, _material, _folder, &normalTexture);
}

void aie::Material::Bind(unsigned int _program)
{
	// pull uniforms from the shader
	int kaUniform = glGetUniformLocation(_program, "Ka");
	int kdUniform = glGetUniformLocation(_program, "Kd");
	int ksUniform = glGetUniformLocation(_program, "Ks");
	int keUniform = glGetUniformLocation(_program, "Ke");
	int opacityUniform = glGetUniformLocation(_program, "opacity");
	int specPowUniform = glGetUniformLocation(_program, "specularPower");

	int alphaTexUniform = glGetUniformLocation(_program, "alphaTexture");
	int ambientTexUniform = glGetUniformLocation(_program, "ambientTexture");
	int diffuseTexUniform = glGetUniformLocation(_program, "diffuseTexture");
	int specTexUniform = glGetUniformLocation(_program, "specularTexture");
	int specHighlightTexUniform = glGetUniformLocation(_program, "specularHighlightTexture");
	int normalTexUniform = glGetUniformLocation(_program, "normalTexture");
	int dispTexUniform = glGetUniformLocation(_program, "displacementTexture");

	// set texture slots (these don't change per material)
	if (diffuseTexUniform >= 0)
		glUniform1i(diffuseTexUniform, 0);
	if (alphaTexUniform >= 0)
		glUniform1i(alphaTexUniform, 1);
	if (ambientTexUniform >= 0)
		glUniform1i(ambientTexUniform, 2);
	if (specTexUniform >= 0)
		glUniform1i(specTexUniform, 3);
	if (specHighlightTexUniform >= 0)
		glUniform1i(specHighlightTexUniform, 4);
	if (normalTexUniform >= 0)
		glUniform1i(normalTexUniform, 5);
	if (dispTexUniform >= 0)
		glUniform1i(dispTexUniform, 6);

	if (kaUniform >= 0)
		glUniform3fv(kaUniform, 1, &ambient[0]);
	if (kdUniform >= 0)
		glUniform3fv(kdUniform, 1, &diffuse[0]);
	if (ksUniform >= 0)
		glUniform3fv(ksUniform, 1, &specular[0]);
	if (keUniform >= 0)
		glUniform3fv(keUniform, 1, &emissive[0]);

	if (opacityUniform >= 0)
		glUniform1f(opacityUniform, opacity);
	if (specPowUniform >= 0)
		glUniform1f(specPowUniform, specularPower);

	BindTexture(GL_TEXTURE0, diffuseTexture);
	BindTexture(GL_TEXTURE1, alphaTexture);
	BindTexture(GL_TEXTURE2, ambientTexture);
	BindTexture(GL_TEXTURE3, specularTexture);
	BindTexture(GL_TEXTURE4, specularHighlightTexture);
	BindTexture(GL_TEXTURE5, normalTexture);
	BindTexture(GL_TEXTURE6, displacementTexture);
}

void aie::Material::AssignColourProperty(aiMaterial* _mat, 
	aiMaterialProperty* _property, vec3* _color)
{
	aiColor3D val;
	if (_mat->Get(_property->mKey.C_Str(), 0, 0, val) == aiReturn_FAILURE)
		return;

	*_color = { val.r, val.g, val.b };
}

void aie::Material::AssignFloatProperty(aiMaterial* _mat, 
	aiMaterialProperty* _property, float* _float)
{
	ai_real val;
	if (_mat->Get(_property->mKey.C_Str(), 0, 0, val) == aiReturn_FAILURE)
		return;

	*_float = val;
}

bool aie::Material::AssignTextureProperty(aiTextureType _type, aiMaterial* _material,
	const string& _path, Texture* _texture)
{
	aiString filePath;
	aiReturn state = aiReturn_FAILURE;
	unsigned int idx = 0;

	for (idx = 0; idx < _material->GetTextureCount(_type); idx++)
		state = _material->GetTexture(_type, idx, &filePath);

	if (idx == _material->GetTextureCount(_type) && state == aiReturn_FAILURE)
		return false;

	_texture->Load(string(_path + "/" + filePath.C_Str()).c_str());
	return true;
}

bool aie::Material::Contains(aiString _string, const char* _delim)
{
	return string(_string.data).find(_delim) != string::npos;
}

void aie::Material::BindTexture(unsigned int _id, Texture& _texture)
{
	glActiveTexture(_id);

	if (_texture.GetHandle() > 0)
		glBindTexture(GL_TEXTURE_2D, _texture.GetHandle());
	else
		glBindTexture(GL_TEXTURE_2D, 0);
}
