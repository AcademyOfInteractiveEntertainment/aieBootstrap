#pragma once

#include <vector>
#include <list>

#include <glm/vec2.hpp>

#include "Light.h"

class SimpleCamera;
class Instance;

const int MAX_LIGHTS = 4;

using std::vector;
using std::list;

using glm::vec2;

class Scene
{
public:
	Scene(SimpleCamera* _cam, vec2 _windowSize, 
		Light& _global, vec3 _ambient);
	~Scene();

	void Update(float _dt, float _time);
	void Draw();
	
	void ImGuiHelper();

	void AddInstance(Instance* _instance);
	void AddPointLight(Light _light);
	void AddPointLight(vec3 _dir, vec3 _colour, float _intensity);

	void SetGlobalLightDir(vec3 _dir);

	SimpleCamera* GetCamera() const;
	vec2 GetWindowSize() const;

	vec3 GetAmbientColour() const;
	void SetAmbientColour(vec3 _colour);

	Light& GetGlobalLight();
	vector<Light>& GetPointLights();

	int GetPointLightCount();

	vec3* GetPointLightPositions();
	vec3* GetPointLightColours();

protected:
	SimpleCamera*	m_camera;
	vec2			m_windowSize;
	list<Instance*>	m_instances;

	Light			m_globalLight;
	vec3			m_ambientLightColor;

	vector<Light>	m_pointLights;
	vec3			m_pointLightPositions[MAX_LIGHTS];
	vec3			m_pointLightColors[MAX_LIGHTS];

};

