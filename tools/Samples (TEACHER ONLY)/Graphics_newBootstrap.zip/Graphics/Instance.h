#pragma once

#include <glm/mat4x4.hpp>
#include <glm/vec3.hpp>

class SimpleCamera;
class Scene;
struct Light;

namespace aie {
	class ShaderProgram;
	class Object;
}

using glm::mat4;
using glm::vec3;

class Instance
{
public:
	Instance(mat4 _trans, aie::Object* _mesh, aie::ShaderProgram* _shader);
	Instance(vec3 _pos, vec3 _euler, vec3 _scale,
		aie::Object* _mesh, aie::ShaderProgram* _shader);

	~Instance() {}

	void Draw(Scene* _scene);

	static mat4 MakeTransform(vec3 _pos, vec3 _euler, vec3 _scale);

protected:
	mat4 m_transform;
	aie::Object* m_mesh;
	aie::ShaderProgram* m_shader;

};

