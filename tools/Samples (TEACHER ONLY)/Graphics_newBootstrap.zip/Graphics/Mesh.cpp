#include "Mesh.h"

#include <glew/glew.h>

#include <assimp/scene.h>
#include <assimp/cimport.h>
#include <vector>
#include <iostream>

Mesh::Mesh()
	: m_triCount(0), m_vao(0), m_vbo(0), m_ibo(0), m_materialIndex(0)
{
}

Mesh::~Mesh()
{
	// If the array does not equal
	// zero, then delete the data
	glDeleteVertexArrays(1, &m_vao);
	glDeleteBuffers(1, &m_vbo);
	glDeleteBuffers(1, &m_ibo);
}

void Mesh::Draw()
{
	glBindVertexArray(m_vao);

	// Check if we are using indices, or just vertex points
	if (m_ibo != 0)
	{
		glDrawElements(GL_TRIANGLES,
			3 * m_triCount, GL_UNSIGNED_INT, 0);
	}
	else
		glDrawArrays(GL_TRIANGLES, 0, 3 * m_triCount);
}

void Mesh::Initialise(unsigned int vertexCount, const Vertex* vertices,
	unsigned int indexCount, unsigned int* indices)
{
	// Check if the mesh is not initialised already
	assert(m_vao == 0);

	// Generate buffers
	glGenBuffers(1, &m_vbo);
	glGenVertexArrays(1, &m_vao);

	// Bind the vertex array, this will be our mesh buffer
	glBindVertexArray(m_vao);

	// Bind the vertex buffer
	glBindBuffer(GL_ARRAY_BUFFER, m_vbo);

	// Fill the vertex buffer
	glBufferData(GL_ARRAY_BUFFER, vertexCount * sizeof(Vertex),
		vertices, GL_STATIC_DRAW);

	// Enable the first element as the position 
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex), 0);

	// Enable the second element as the normal
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 4, GL_FLOAT, GL_TRUE, sizeof(Vertex), (void*)16);

	// Enable the third element as the texture coordinate
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)32);

	// Bind the indices if there are any defined

	if (indexCount != 0)
	{
		glGenBuffers(1, &m_ibo);

		// Bind the vertex buffer
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_ibo);

		// Fill the vertex buffer
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, indexCount *
			sizeof(unsigned int), indices, GL_STATIC_DRAW);

		m_triCount = indexCount / 3;
	}
	else
	{
		m_triCount = vertexCount / 3;
	}

	// Unbind our buffers
	glBindVertexArray(0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void Mesh::InitialiseQuad()
{
	// Check if the mesh is not initialised already
	assert(m_vao == 0);

	// Generate buffers
	glGenBuffers(1, &m_vbo);
	glGenVertexArrays(1, &m_vao);

	// Bind the vertex array, this will be our mesh buffer
	glBindVertexArray(m_vao);

	// Bind the vertex buffer
	glBindBuffer(GL_ARRAY_BUFFER, m_vbo);

	// Define the 6 vertices for our two triangles to make a quad, 
	// in a counter-clockwise direction.
	Vertex vertices[6];
	vertices[0].position = { -0.5f, 0,  0.5f, 1.f };
	vertices[1].position = { 0.5f, 0,  0.5f, 1.f };
	vertices[2].position = { -0.5f, 0, -0.5f, 1.f };

	vertices[3].position = { -0.5f, 0, -0.5f, 1.f };
	vertices[4].position = { 0.5f, 0,  0.5f, 1.f };
	vertices[5].position = { 0.5f, 0, -0.5f, 1.f };

	vertices[0].normal = { 0,1,0,0 };
	vertices[1].normal = { 0,1,0,0 };
	vertices[2].normal = { 0,1,0,0 };
	vertices[3].normal = { 0,1,0,0 };
	vertices[4].normal = { 0,1,0,0 };
	vertices[5].normal = { 0,1,0,0 };

	vertices[0].texCoord = { 0, 1 }; // Bottom Left
	vertices[1].texCoord = { 1, 1 }; // Bottom Right
	vertices[2].texCoord = { 0, 0 }; // Top Left
	vertices[3].texCoord = { 0, 0 }; // Top Left
	vertices[4].texCoord = { 1, 1 }; // Bottom Right
	vertices[5].texCoord = { 1, 0 }; // Top Right


	// Fill the vertex buffer
	glBufferData(GL_ARRAY_BUFFER, 6 * sizeof(Vertex),
		vertices, GL_STATIC_DRAW);

	// Now we will enable the first element as the position
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex), 0);

	// Enable the second element as the normal
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 4, GL_FLOAT, GL_TRUE, sizeof(Vertex), (void*)16);

	// Enable the third element as the texture coordinate
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)32);

	// Next we unbind the buffers
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	// This is a quad made up of two triangles
	m_triCount = 2;
}

void Mesh::InitialiseFromAssimp(const aiMesh* _mesh, bool _flipTextureV)
{
	vector<Vertex> verts;

	for (unsigned int v = 0; v < _mesh->mNumVertices; v++)
	{
		Vertex newVert;

		aiVector3D vert = _mesh->mVertices[v];
		newVert.position = { vert.x, vert.y, vert.z, 1 };

		if (_mesh->HasNormals())
		{
			aiVector3D norm = _mesh->mNormals[v];
			newVert.normal = { norm.x, norm.y, norm.z, 1 };
		}

		if (_mesh->HasTextureCoords(0))
		{
			aiVector3D uv = _mesh->mTextureCoords[0][v];
			newVert.texCoord = { uv.x, (_flipTextureV ? -uv.y : uv.y ) };
		}

		verts.push_back(newVert);
	}

	// extract indicies from the first mesh
	int numFaces = _mesh->mNumFaces;
	vector<unsigned int> indices;
	for (int i = 0; i < numFaces; i++)
	{
		indices.push_back(_mesh->mFaces[i].mIndices[1]);
		indices.push_back(_mesh->mFaces[i].mIndices[2]);
		indices.push_back(_mesh->mFaces[i].mIndices[0]);

		// generate a second triangle for quads
		if (_mesh->mFaces[i].mNumIndices == 4)
		{
			indices.push_back(_mesh->mFaces[i].mIndices[2]);
			indices.push_back(_mesh->mFaces[i].mIndices[3]);
			indices.push_back(_mesh->mFaces[i].mIndices[0]);
		}
	}

	m_materialIndex = _mesh->mMaterialIndex;

	Initialise((unsigned int)verts.size(), verts.data(), (unsigned int)indices.size(), indices.data());
}
