#pragma once

#include "aie/bootstrap/Application.h"

#include <glm/mat4x4.hpp>

#include "Object.h"
#include "RenderTarget.h"
#include "Shader.h"
#include "SimpleCamera.h"

using glm::mat4;

class Scene;

class GraphicsApp : public aie::Application {
public:

	GraphicsApp();
	virtual ~GraphicsApp();

	virtual bool Startup();
	virtual void Shutdown();

	virtual void Update(float deltaTime);
	virtual void Draw();

protected:

	bool LaunchShaders();

	SimpleCamera m_camera;

	mat4	m_viewMatrix;
	mat4	m_projectionMatrix;

	aie::ShaderProgram	m_simpleShader;
	aie::ShaderProgram  m_colorShader;
	aie::ShaderProgram  m_phongShader;
	aie::ShaderProgram	m_texturedShader;
	aie::ShaderProgram  m_normalLitShader;

	aie::RenderTarget	m_renderTarget;

	Scene* m_scene;

	aie::Object m_spearMesh;
	mat4 m_spearTransform;

	vec3 m_ambientLight;

};