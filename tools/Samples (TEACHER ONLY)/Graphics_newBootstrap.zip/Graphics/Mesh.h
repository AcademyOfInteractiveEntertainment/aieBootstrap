#pragma once

#include <glm/vec2.hpp>
#include <glm/vec4.hpp>

#include <vector>

using glm::vec2;
using glm::vec4;

using std::vector;

struct aiMesh;

class Mesh
{
public:
	struct Vertex
	{
		vec4 position;
		vec4 normal;
		vec2 texCoord;
	};

	Mesh();
	virtual ~Mesh();

	virtual void Draw();

	void Initialise(unsigned int vertexCount, const Vertex* vertices,
		unsigned int indexCount = 0, unsigned int* indices = nullptr);

	void InitialiseQuad();
	void InitialiseFromAssimp(const aiMesh* _mesh, bool _flipTextureV = false);

	unsigned int GetMaterialIndex() { return m_materialIndex; }

protected:
	unsigned int m_triCount;
	unsigned int m_vao; // the Vertex Array Object
	unsigned int m_vbo; // the Vertex Buffer Object
	unsigned int m_ibo; // the Index Buffer Object
	unsigned int m_materialIndex;

};

