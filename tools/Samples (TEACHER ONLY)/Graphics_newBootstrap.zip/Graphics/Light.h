#pragma once

#include <glm/vec3.hpp>

using glm::vec3;

struct Light
{
public:
	Light()
	{
		direction = vec3(0);
		color = vec3(1);
	}

	Light(vec3 _position, vec3 _color, float _intensity)
	{
		direction = _position;
		color = _color * _intensity;
	}

	vec3 direction;
	vec3 color;

};