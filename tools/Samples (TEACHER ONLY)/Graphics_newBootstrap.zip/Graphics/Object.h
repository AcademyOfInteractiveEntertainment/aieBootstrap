#pragma once

#include <string>
#include <vector>

#include "Material.h"
#include "Mesh.h"

using std::string;
using std::vector;

namespace aie
{
	class Object
	{
	public:
		Object();
		~Object();

		void Load(const char* _fileName, bool _flipTextureV = false, bool _loadTextures = true);
		void Draw();

		const string& getFilename() const { return m_fileName; }

		size_t GetMaterialCount() const { return m_materials.size(); }
		Material& GetMaterial(size_t index) { return *m_materials[index]; }

	private:
		string m_fileName;
		vector<Material*> m_materials;
		vector<Mesh*> m_meshes;

	};
}