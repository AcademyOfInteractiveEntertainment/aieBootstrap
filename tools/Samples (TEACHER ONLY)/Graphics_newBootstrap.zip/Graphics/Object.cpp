#include "Object.h"

#include <assimp/scene.h>
#include <assimp/cimport.h>

#include <glew/glew.h>

aie::Object::Object()
{
}

aie::Object::~Object()
{
	for (auto& mesh : m_meshes)
	{
		delete mesh;
	}

	for (auto& material : m_materials)
	{
		delete material;
	}
}

void aie::Object::Load(const char* _fileName, bool _flipTextureV, bool _loadTextures)
{
	const aiScene* scene = aiImportFile(_fileName, 0);

	string path = _fileName;
	path = path.substr(0, path.find_last_of('/'));

	for (unsigned int i = 0; i < scene->mNumMeshes; i++)
	{
		Mesh* mesh = new Mesh();
		mesh->InitialiseFromAssimp(scene->mMeshes[i], _flipTextureV);
		m_meshes.push_back(mesh);
	}

	for (unsigned int i = 0; i < scene->mNumMaterials; i++)
	{
		Material* material = new Material();
		material->LoadFromAssimp(scene->mMaterials[i], path);
		m_materials.push_back(material);
	}
}

void aie::Object::Draw()
{
	int program = -1;
	glGetIntegerv(GL_CURRENT_PROGRAM, &program);

	if (program == -1) {
		printf("No shader bound!\n");
		return;
	}

	// pull uniforms from the shader
	int kaUniform = glGetUniformLocation(program, "Ka");
	int kdUniform = glGetUniformLocation(program, "Kd");
	int ksUniform = glGetUniformLocation(program, "Ks");
	int keUniform = glGetUniformLocation(program, "Ke");
	int opacityUniform = glGetUniformLocation(program, "opacity");
	int specPowUniform = glGetUniformLocation(program, "specularPower");

	int alphaTexUniform = glGetUniformLocation(program, "alphaTexture");
	int ambientTexUniform = glGetUniformLocation(program, "ambientTexture");
	int diffuseTexUniform = glGetUniformLocation(program, "diffuseTexture");
	int specTexUniform = glGetUniformLocation(program, "specularTexture");
	int specHighlightTexUniform = glGetUniformLocation(program, "specularHighlightTexture");
	int normalTexUniform = glGetUniformLocation(program, "normalTexture");
	int dispTexUniform = glGetUniformLocation(program, "displacementTexture");

	// set texture slots (these don't change per material)
	if (diffuseTexUniform >= 0)
		glUniform1i(diffuseTexUniform, 0);
	if (alphaTexUniform >= 0)
		glUniform1i(alphaTexUniform, 1);
	if (ambientTexUniform >= 0)
		glUniform1i(ambientTexUniform, 2);
	if (specTexUniform >= 0)
		glUniform1i(specTexUniform, 3);
	if (specHighlightTexUniform >= 0)
		glUniform1i(specHighlightTexUniform, 4);
	if (normalTexUniform >= 0)
		glUniform1i(normalTexUniform, 5);
	if (dispTexUniform >= 0)
		glUniform1i(dispTexUniform, 6);

	for (auto& mesh : m_meshes)
	{
		if (mesh->GetMaterialIndex() < m_materials.size())
			m_materials[mesh->GetMaterialIndex()]->Bind(program);

		mesh->Draw();
	}
}
