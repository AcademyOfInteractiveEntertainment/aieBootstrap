#pragma once

#include "aie/bootstrap/Texture.h"

#include <glm/vec3.hpp>
#include <assimp/types.h>

using glm::vec3;

struct aiMaterial;
struct aiMaterialProperty;
enum aiTextureType;

namespace aie
{
	class Material {
	public:

		Material() : ambient(1), diffuse(1), specular(0), emissive(0), specularPower(1), opacity(1) {}
		~Material() {}

		void LoadFromAssimp(aiMaterial* _material, const string& _folder);
		void Bind(unsigned int _program);

		vec3 ambient;
		vec3 diffuse;
		vec3 specular;
		vec3 emissive;

		float specularPower;
		float opacity;

		Texture diffuseTexture;				// bound slot 0
		Texture alphaTexture;				// bound slot 1
		Texture ambientTexture;				// bound slot 2
		Texture specularTexture;			// bound slot 3
		Texture specularHighlightTexture;	// bound slot 4
		Texture normalTexture;				// bound slot 5
		Texture displacementTexture;		// bound slot 6

	private:
		void AssignColourProperty(aiMaterial* _mat, aiMaterialProperty* _property, vec3* _color);

		void AssignFloatProperty(aiMaterial* _mat, aiMaterialProperty* _property, float* _float);

		bool AssignTextureProperty(aiTextureType _type, aiMaterial* _material, 
			const string& _path, Texture* _texture);

		bool Contains(aiString _string, const char* _delim);

		void BindTexture(unsigned int _id, Texture& _texture);

	};
}