#pragma once

#include <glm/vec2.hpp>
#include <glm/vec3.hpp>
#include <glm/mat4x4.hpp>

using glm::vec2;
using glm::vec3;
using glm::mat4;

class SimpleCamera
{
public:
	SimpleCamera();
	~SimpleCamera() {}

	void Update(float _dt);
	vec3 Position() const;
	mat4 GetViewMatrix();
	mat4 GetProjectionMatrix(float _w, float _h);
	mat4 GetTransform(vec3 _pos, vec3 _euler, vec3 _scale);

private:
	float m_theta;
	float m_phi;

	float m_turnSpeed;
	float m_moveSpeed;

	vec3 m_position;
	vec2 m_lastMouse;

};

