#include "Instance.h"

#include <glm/glm.hpp>
#include <glm/ext.hpp>

#include "Object.h"
#include "Shader.h"
#include "Scene.h"
#include "SimpleCamera.h"

Instance::Instance(mat4 _trans, aie::Object* _mesh, aie::ShaderProgram* _shader)
	: m_transform(_trans), m_shader(_shader), m_mesh(_mesh)
{
}

Instance::Instance(vec3 _pos, vec3 _euler, vec3 _scale, aie::Object* _mesh, aie::ShaderProgram* _shader)
	: m_shader(_shader), m_mesh(_mesh)
{
	m_transform = MakeTransform(_pos, _euler, _scale);
}

void Instance::Draw(Scene* _scene)
{
	// Set the shader pipeline
	m_shader->Bind();
	// Bind all relevant uniforms for our shaders
	auto pvm = _scene->GetCamera()->GetProjectionMatrix(
		_scene->GetWindowSize().x, _scene->GetWindowSize().y) *
		_scene->GetCamera()->GetViewMatrix() * m_transform;
	m_shader->BindUniform("ProjectionViewModel", pvm);
	m_shader->BindUniform("ModelMatrix", m_transform);

	// Bind the directional light we defined
	m_shader->BindUniform("AmbientColor", _scene->GetAmbientColour());
	m_shader->BindUniform("LightColor", _scene->GetGlobalLight().color);
	m_shader->BindUniform("LightDirection", _scene->GetGlobalLight().direction);

	// Bind the camera position
	m_shader->BindUniform("CameraPosition", _scene->GetCamera()->Position());

	int numberOfLights = _scene->GetPointLightCount();
	m_shader->BindUniform("numLights", numberOfLights);
	m_shader->BindUniform("PointLightPositions",
		numberOfLights, _scene->GetPointLightPositions());
	m_shader->BindUniform("PointLightColors",
		numberOfLights, _scene->GetPointLightColours());

	m_mesh->Draw();
}

mat4 Instance::MakeTransform(vec3 _pos, vec3 _euler, vec3 _scale)
{
	return glm::translate(mat4(1), _pos)
		* glm::rotate(mat4(1), glm::radians(_euler.z), vec3(0, 0, 1))
		* glm::rotate(mat4(1), glm::radians(_euler.y), vec3(0, 1, 0))
		* glm::rotate(mat4(1), glm::radians(_euler.x), vec3(1, 0, 0))
		* glm::scale(mat4(1), _scale);
}
