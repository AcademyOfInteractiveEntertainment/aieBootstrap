#include "SimpleCamera.h"

#include <glm/glm.hpp>
#include <glm/ext.hpp>

#include "aie/bootstrap/Input.h"

using aie::Input;

SimpleCamera::SimpleCamera()
	: m_phi(0), m_theta(0), m_turnSpeed(glm::radians(180.f)), m_moveSpeed(5.f),
	m_lastMouse({ 0.f, 0.f }), m_position({ -10.f, 2.f, 0.f })
{
}

void SimpleCamera::Update(float _dt)
{
	Input* input = Input::GetInstance();
	float thetaR = glm::radians(m_theta);
	float phiR = glm::radians(m_phi);

	vec3 forward(glm::cos(phiR) * glm::cos(thetaR), glm::sin(phiR),
		glm::cos(phiR) * glm::sin(thetaR));
	vec3 right(-glm::sin(thetaR), 0, glm::cos(thetaR));
	vec3 up(0, 1, 0);

	// We will use WASD to move and the Q & E to go up and down
	if (input->IsKeyDown(aie::INPUT_KEY_W))
		m_position += forward * _dt * m_moveSpeed;
	if (input->IsKeyDown(aie::INPUT_KEY_S))
		m_position -= forward * _dt * m_moveSpeed;
	if (input->IsKeyDown(aie::INPUT_KEY_A))
		m_position -= right * _dt * m_moveSpeed;
	if (input->IsKeyDown(aie::INPUT_KEY_D))
		m_position += right * _dt * m_moveSpeed;

	if (input->IsKeyDown(aie::INPUT_KEY_Q))
		m_position -= up * _dt * m_moveSpeed;
	if (input->IsKeyDown(aie::INPUT_KEY_E))
		m_position += up * _dt * m_moveSpeed;

	// Get the mouse coordinates
	float mx = (float)input->GetMouseX();
	float my = (float)input->GetMouseY();

	// If the right button is held down, increment theta and phi (rotate)
	if (input->IsMouseButtonDown(aie::INPUT_MOUSE_BUTTON_RIGHT))
	{
		m_theta += m_turnSpeed * (mx - m_lastMouse.x) * _dt;
		m_phi += m_turnSpeed * (my - m_lastMouse.y) * _dt;
	}

	m_lastMouse = vec2(mx, my);
}

vec3 SimpleCamera::Position() const
{
	return m_position;
}

mat4 SimpleCamera::GetViewMatrix()
{
	float thetaR = glm::radians(m_theta);
	float phiR = glm::radians(m_phi);
	vec3 forward(glm::cos(phiR) * glm::cos(thetaR), glm::sin(phiR),
		glm::cos(phiR) * glm::sin(thetaR));

	return glm::lookAt(m_position, m_position + forward,
		glm::vec3(0, 1, 0));
}

mat4 SimpleCamera::GetProjectionMatrix(float _w, float _h)
{
	return glm::perspective(glm::pi<float>() * 0.25f, _w / _h,
		0.1f, 1000.f);
}

mat4 SimpleCamera::GetTransform(vec3 _pos, vec3 _euler, vec3 _scale)
{
	return glm::translate(mat4(1), _pos)
		* glm::rotate(mat4(1), glm::radians(_euler.z), vec3(0, 0, 1))
		* glm::rotate(mat4(1), glm::radians(_euler.y), vec3(0, 1, 0))
		* glm::rotate(mat4(1), glm::radians(_euler.x), vec3(1, 0, 0))
		* glm::scale(mat4(1), _scale);
}
