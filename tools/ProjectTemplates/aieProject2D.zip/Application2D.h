#pragma once

#include "aie/bootstrap/Application.h"
#include "aie/bootstrap/Renderer2D.h"

class $safeprojectname$App : public aie::Application {
public:

	$safeprojectname$App();
	virtual ~$safeprojectname$App();

	virtual bool Startup();
	virtual void Shutdown();

	virtual void Update(float deltaTime);
	virtual void Draw();

protected:

	aie::Renderer2D* m_2dRenderer;
	aie::Font* m_font;

};