#include "$safeprojectname$App.h"
#include "aie/bootstrap/Gizmos.h"
#include "aie/bootstrap/Input.h"
#include "aie/bootstrap/Font.h"
#include <glm/glm.hpp>
#include <glm/ext.hpp>

using glm::vec3;
using glm::vec4;
using glm::mat4;
using aie::Gizmos;

$safeprojectname$App::$safeprojectname$App() {

}

$safeprojectname$App::~$safeprojectname$App() {

}

bool $safeprojectname$App::Startup() {
	
	m_2dRenderer = new aie::Renderer2D();

	// TODO: remember to change this when redistributing a build!
	// the following path would be used instead: "./font/consolas.ttf"
	m_font = new aie::Font("../bin/font/consolas.ttf", 32);

	return true;
}

void $safeprojectname$App::Shutdown() {

	delete m_font;
	delete m_2dRenderer;
}

void $safeprojectname$App::Update(float deltaTime) {

	// input example
	aie::Input* input = aie::Input::GetInstance();

	// exit the application
	if (input->IsKeyDown(aie::INPUT_KEY_ESCAPE))
		Quit();
}

void $safeprojectname$App::Draw() {

	// wipe the screen to the background colour
	ClearScreen();

	// begin drawing sprites
	m_2dRenderer->Begin();

	// draw your stuff here!

	// output some text, uses the last used colour
	m_2dRenderer->DrawText(m_font, "Press ESC to quit", 0, 0);

	// done drawing sprites
	m_2dRenderer->End();
}