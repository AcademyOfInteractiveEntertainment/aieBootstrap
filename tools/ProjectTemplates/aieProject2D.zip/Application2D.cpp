#include "$safeprojectname$App.h"
#include "Texture.h"
#include "Font.h"
#include "Input.h"

$safeprojectname$App::$safeprojectname$App() {

}

$safeprojectname$App::~$safeprojectname$App() {

}

bool $safeprojectname$App::startup() {
	
	m_2dRenderer = new aie::Renderer2D();

	m_texture = new aie::Texture("./textures/ship.png");

	m_font = new aie::Font("./font/consolas.ttf", 32);

	m_cameraX = 0;
	m_cameraY = 0;

	return true;
}

void $safeprojectname$App::shutdown() {

	delete m_font;
	delete m_texture;
	delete m_2dRenderer;
}

void $safeprojectname$App::update(float deltaTime) {

	// input example
	aie::Input* input = aie::Input::getInstance();

	// use arrow keys to move camera
	if (input->isKeyDown(aie::INPUT_KEY_UP))
		m_cameraY += 500.0f * deltaTime;

	if (input->isKeyDown(aie::INPUT_KEY_DOWN))
		m_cameraY -= 500.0f * deltaTime;

	if (input->isKeyDown(aie::INPUT_KEY_LEFT))
		m_cameraX -= 500.0f * deltaTime;

	if (input->isKeyDown(aie::INPUT_KEY_RIGHT))
		m_cameraX += 500.0f * deltaTime;

	// exit when escape is pressed
	if (input->isKeyDown(aie::INPUT_KEY_ESCAPE))
		quit();
}

void $safeprojectname$App::draw() {

	// wipe the screen to the background colour
	clearScreen();

	// position the camera before drawing
	m_2dRenderer->setCameraPos(m_cameraX, m_cameraY);

	// begin drawing sprites
	m_2dRenderer->begin();

	m_2dRenderer->drawSprite(m_texture, 200, 200);

	// draw the framerate
	char fps[32];
	sprintf_s(fps, 32, "FPS: %i", getFPS());
	m_2dRenderer->drawText(m_font, fps, 0, getWindowHeight() - 32);

	// done drawing sprites
	m_2dRenderer->end();
}