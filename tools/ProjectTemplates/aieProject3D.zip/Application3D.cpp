#include "$safeprojectname$App.h"
#include "aie/bootstrap/Gizmos.h"
#include "aie/bootstrap/Input.h"
#include <glm/glm.hpp>
#include <glm/ext.hpp>

using glm::vec3;
using glm::vec4;
using glm::mat4;
using aie::Gizmos;

$safeprojectname$App::$safeprojectname$App() {

}

$safeprojectname$App::~$safeprojectname$App() {

}

bool $safeprojectname$App::Startup() {
	
	SetBackgroundColour(0.25f, 0.25f, 0.25f);

	// initialise gizmo primitive counts
	Gizmos::Create(10000, 10000, 10000, 10000);

	// create simple camera transforms
	m_viewMatrix = glm::lookAt(vec3(10), vec3(0), vec3(0, 1, 0));
	m_projectionMatrix = glm::perspective(glm::pi<float>() * 0.25f, 16.0f / 9.0f, 0.1f, 1000.0f);

	return true;
}

void $safeprojectname$App::Shutdown() {

	Gizmos::Destroy();
}

void $safeprojectname$App::Update(float deltaTime) {

	// wipe the gizmos clean for this frame
	Gizmos::Clear();

	// draw a simple grid with gizmos
	vec4 white(1);
	vec4 black(0, 0, 0, 1);
	for (int i = 0; i < 21; ++i) {
		Gizmos::AddLine(vec3(-10 + i, 0, 10),
			vec3(-10 + i, 0, -10),
			i == 10 ? white : black);
		Gizmos::AddLine(vec3(10, 0, -10 + i),
			vec3(-10, 0, -10 + i),
			i == 10 ? white : black);
	}

	// add a transform so that we can see the axis
	Gizmos::AddTransform(mat4(1));

	// quit if we press escape
	aie::Input* input = aie::Input::GetInstance();

	if (input->IsKeyDown(aie::INPUT_KEY_ESCAPE))
		Quit();
}

void $safeprojectname$App::Draw() {

	// wipe the screen to the background colour
	ClearScreen();

	// update perspective based on screen size
	m_projectionMatrix = glm::perspective(glm::pi<float>() * 0.25f, GetWindowWidth() / (float)GetWindowHeight(), 0.1f, 1000.0f);

	Gizmos::Draw(m_projectionMatrix * m_viewMatrix);
}