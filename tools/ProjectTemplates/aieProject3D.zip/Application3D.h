#pragma once

#include "Application.h"
#include "Camera.h"

class $safeprojectname$App : public aie::Application {
public:

	$safeprojectname$App();
	virtual ~$safeprojectname$App();

	virtual bool startup();
	virtual void shutdown();

	virtual void update(float deltaTime);
	virtual void draw();

protected:

	aie::Camera*		m_camera;
};