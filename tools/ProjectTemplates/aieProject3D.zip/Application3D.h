#pragma once

#include "aie/bootstrap/Application.h"
#include <glm/mat4x4.hpp>

class $safeprojectname$App : public aie::Application {
public:

	$safeprojectname$App();
	virtual ~$safeprojectname$App();

	virtual bool Startup();
	virtual void Shutdown();

	virtual void Update(float deltaTime);
	virtual void Draw();

protected:

	glm::mat4	m_viewMatrix;
	glm::mat4	m_projectionMatrix;
};